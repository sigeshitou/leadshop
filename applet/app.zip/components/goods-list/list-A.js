(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/goods-list/list-A"],{"1bb2":function(n,t,e){},2728:function(n,t,e){"use strict";e.r(t);var o=e("c4d5"),r=e.n(o);for(var a in o)["default"].indexOf(a)<0&&function(n){e.d(t,n,(function(){return o[n]}))}(a);t["default"]=r.a},"49a5":function(n,t,e){"use strict";var o;e.d(t,"b",(function(){return r})),e.d(t,"c",(function(){return a})),e.d(t,"a",(function(){return o}));var r=function(){var n=this,t=n.$createElement;n._self._c},a=[]},"7dec":function(n,t,e){"use strict";e.r(t);var o=e("49a5"),r=e("2728");for(var a in r)["default"].indexOf(a)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(a);e("ba88");var i,c=e("f0c5"),u=Object(c["a"])(r["default"],o["b"],o["c"],!1,null,"5ba2a518",null,!1,o["a"],i);t["default"]=u.exports},ba88:function(n,t,e){"use strict";var o=e("1bb2"),r=e.n(o);r.a},c4d5:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){e.e("components/he-cart").then(function(){return resolve(e("a5b4"))}.bind(null,e)).catch(e.oe)},r={name:"list-A",components:{heCart:o},props:{list:{type:Array,default:function(){return[]}}},data:function(){return{isShopping:!1,goods:{}}},methods:{navigateTo:function(n){this.$emit("navigateTo",n)},shopping:function(n){var t=this;this.$heshop.goods("get",n.id,{type:"param"}).then((function(e){t.goods=Object.assign(n,e),t.isShopping=!0})).catch((function(n){console.error(n),t.$toError()}))}}};t.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/goods-list/list-A-create-component',
    {
        'components/goods-list/list-A-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7dec"))
        })
    },
    [['components/goods-list/list-A-create-component']]
]);
