module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.1.0",
    "AppURL": "https://dev.91bd.cn/index.php",
    "siteroot": "https://dev.91bd.cn/index.php",
    "design_method": "3"
}