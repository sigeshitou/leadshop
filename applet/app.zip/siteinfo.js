module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.1.3",
    "AppURL": "https://weapp.leadshop.vip/index.php",
    "siteroot": "https://weapp.leadshop.vip/index.php",
    "design_method": "3"
}