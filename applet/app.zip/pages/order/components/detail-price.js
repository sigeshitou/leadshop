(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-price"],{"23f9":function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return f})),e.d(n,"a",(function(){return u}));var r=function(){var t=this,n=t.$createElement;t._self._c},f=[]},"73bf":function(t,n,e){},7963:function(t,n,e){"use strict";e.r(n);var u=e("23f9"),r=e("f6b5");for(var f in r)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(f);e("f9b6");var a,i=e("f0c5"),c=Object(i["a"])(r["default"],u["b"],u["c"],!1,null,"84576156",null,!1,u["a"],a);n["default"]=c.exports},"8c77":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"detail-price",props:{goodsAmount:{type:String,default:function(){return""}},freightAmount:{type:String,default:function(){return""}},payAmount:{type:String,default:function(){return""}},status:{type:Number,default:function(){return 0}}}};n.default=u},f6b5:function(t,n,e){"use strict";e.r(n);var u=e("8c77"),r=e.n(u);for(var f in u)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(f);n["default"]=r.a},f9b6:function(t,n,e){"use strict";var u=e("73bf"),r=e.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-price-create-component',
    {
        'pages/order/components/detail-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7963"))
        })
    },
    [['pages/order/components/detail-price-create-component']]
]);
