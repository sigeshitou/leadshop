(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-price"],{1698:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return f})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement,e=(t._self._c,t._f("floatPrice")(t.goodsAmount)),r=t._f("floatPrice")(t.freightAmount);t.$mp.data=Object.assign({},{$root:{f0:e,f1:r}})},f=[]},"1a68":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"submit-price",props:{goodsAmount:{type:Number},freightAmount:{type:Number}}};n.default=r},3983:function(t,n,e){},"98fd":function(t,n,e){"use strict";var r=e("3983"),u=e.n(r);u.a},ef31:function(t,n,e){"use strict";e.r(n);var r=e("1a68"),u=e.n(r);for(var f in r)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(f);n["default"]=u.a},fd7a:function(t,n,e){"use strict";e.r(n);var r=e("1698"),u=e("ef31");for(var f in u)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(f);e("98fd");var a,o=e("f0c5"),i=Object(o["a"])(u["default"],r["b"],r["c"],!1,null,"fba7296a",null,!1,r["a"],a);n["default"]=i.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-price-create-component',
    {
        'pages/order/components/submit-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("fd7a"))
        })
    },
    [['pages/order/components/submit-price-create-component']]
]);
