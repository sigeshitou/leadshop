(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-address"],{"1edc":function(n,t,e){"use strict";var i;e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return i}));var u=function(){var n=this,t=n.$createElement;n._self._c},o=[]},"78b5":function(n,t,e){"use strict";e.r(t);var i=e("fab5"),u=e.n(i);for(var o in i)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return i[n]}))}(o);t["default"]=u.a},"93d1":function(n,t,e){"use strict";var i=e("eb4c"),u=e.n(i);u.a},d78f:function(n,t,e){"use strict";e.r(t);var i=e("1edc"),u=e("78b5");for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);e("93d1");var a,c=e("f0c5"),r=Object(c["a"])(u["default"],i["b"],i["c"],!1,null,"13e538c0",null,!1,i["a"],a);t["default"]=r.exports},eb4c:function(n,t,e){},fab5:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"submit-address",props:{value:{type:Object}},computed:{consigneeInfo:{get:function(){return this.value},set:function(n){this.$emit("input",n)}}},methods:{navigateTo:function(){var t="/pages/user/shipping-address?submit=1";this.consigneeInfo&&(t+="&id="+this.consigneeInfo.id),n.navigateTo({url:t})},getDetail:function(){var n=this;this.$heshop.address("get",{behavior:"default"}).then((function(t){t&&(n.consigneeInfo=t)})).catch((function(n){console.error(n)}))}},mounted:function(){this.getDetail()}};t.default=e}).call(this,e("543d")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-address-create-component',
    {
        'pages/order/components/submit-address-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("d78f"))
        })
    },
    [['pages/order/components/submit-address-create-component']]
]);
