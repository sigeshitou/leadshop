(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/separate/separate"],{"4d5a":function(t,e,n){"use strict";var a;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return a}));var r=function(){var t=this,e=t.$createElement;t._self._c},u=[]},"64f7":function(t,e,n){"use strict";n.r(e);var a=n("ec7a"),r=n.n(a);for(var u in a)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(u);e["default"]=r.a},9990:function(t,e,n){"use strict";n.r(e);var a=n("4d5a"),r=n("64f7");for(var u in r)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(u);var c,f=n("f0c5"),i=Object(f["a"])(r["default"],a["b"],a["c"],!1,null,null,null,!1,a["a"],c);e["default"]=i.exports},ec7a:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},data:function(){return{}},computed:{margin:function(){return 1==this.facade.chamfer_style?0:10}}};e.default=a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/separate/separate-create-component',
    {
        'pages/fitment/separate/separate-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("9990"))
        })
    },
    [['pages/fitment/separate/separate-create-component']]
]);
