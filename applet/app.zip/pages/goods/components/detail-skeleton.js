(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{"0c28":function(n,e,t){"use strict";var u;t.d(e,"b",(function(){return f})),t.d(e,"c",(function(){return r})),t.d(e,"a",(function(){return u}));var f=function(){var n=this,e=n.$createElement;n._self._c},r=[]},1798:function(n,e,t){},b8e0:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-skeleton"};e.default=u},bfeb:function(n,e,t){"use strict";t.r(e);var u=t("b8e0"),f=t.n(u);for(var r in u)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(r);e["default"]=f.a},c5f4:function(n,e,t){"use strict";t.r(e);var u=t("0c28"),f=t("bfeb");for(var r in f)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return f[n]}))}(r);t("f076");var a,c=t("f0c5"),o=Object(c["a"])(f["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],a);e["default"]=o.exports},f076:function(n,e,t){"use strict";var u=t("1798"),f=t.n(u);f.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
