(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-basic-information"],{"15c6":function(e,t,n){"use strict";var a;n.d(t,"b",(function(){return u})),n.d(t,"c",(function(){return r})),n.d(t,"a",(function(){return a}));var u=function(){var e=this,t=e.$createElement;e._self._c;e._isMounted||(e.e0=function(t){e.show=!0})},r=[]},"57a8":function(e,t,n){"use strict";var a=n("7b7a"),u=n.n(a);u.a},"7b7a":function(e,t,n){},abf8:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){n.e("components/he-share").then(function(){return resolve(n("3f1e"))}.bind(null,n)).catch(n.oe)},u={name:"detail-basic-information",components:{heShare:a},props:{name:{type:String,default:""},price:{type:String,default:""},unit:{type:String,default:""},linePrice:{type:String,default:""},sales:{type:Number,default:0},virtual_sales:{type:Number,default:0},goodsId:{type:Number,default:function(){return 0}},goods:{type:Object}},data:function(){return{show:!1,list:[]}},methods:{}};t.default=u},bde5:function(e,t,n){"use strict";n.r(t);var a=n("abf8"),u=n.n(a);for(var r in a)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(r);t["default"]=u.a},ff37:function(e,t,n){"use strict";n.r(t);var a=n("15c6"),u=n("bde5");for(var r in u)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(r);n("57a8");var o,i=n("f0c5"),f=Object(i["a"])(u["default"],a["b"],a["c"],!1,null,"63de65c4",null,!1,a["a"],o);t["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-basic-information-create-component',
    {
        'pages/goods/components/detail-basic-information-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("ff37"))
        })
    },
    [['pages/goods/components/detail-basic-information-create-component']]
]);
